USE MuzikDB;
GO

CREATE TRIGGER TarihDegismez
ON CalmaListeleri
AFTER UPDATE
AS
BEGIN

IF UPDATE(Olusturulma_tarihi)
    BEGIN
        RAISERROR (' Kay�tlar�n olu�turulma  tarihi de�i�tirilemez', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;
GO

















