USE MuzikDB;
GO

CREATE TABLE SilinenSarkilar(
giris_id INT IDENTITY(1,1) PRIMARY KEY,
Sarki_adi NVARCHAR(100),
Silinme_tarihi DATETIME DEFAULT GETDATE(),
Silen_kullanici NVARCHAR(50)
);
GO
CREATE TRIGGER silinensarkiyedekleme
on Sarkilar
AFTER DELETE
AS
BEGIN
INSERT INTO SilinenSarkilar(Sarki_adi,Silen_kullanici)
SELECT ad , SYSTEM_USER FROM deleted;

end;
go