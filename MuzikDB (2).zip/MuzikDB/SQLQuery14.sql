CREATE TRIGGER trg_SarkiIsimKontrol
ON Sarkilar
AFTER INSERT, UPDATE
AS
BEGIN
    /*E�er eklenen/g�ncellenen kay�tlar i�inde;
    -- Ayn� Alb�m ID ve Ayn� �ark� Ad�na sahip birden fazla kay�t olu�ursa*/
    IF EXISTS (
        SELECT s.Album_id, s.Ad
        FROM Sarkilar s
        INNER JOIN inserted i ON s.Album_id = i.Album_id AND s.Ad = i.Ad
        GROUP BY s.Album_id, s.Ad
        HAVING COUNT(*) > 1
    )
    BEGIN
     
        RAISERROR ('HATA: Bu alb�mde bu isimde bir �ark� zaten mevcut! Ayn� isimde iki �ark� olamaz.', 16, 1);
      
        ROLLBACK TRANSACTION;
    END
END;
GO