USE MuzikDB;
GO
/*Bunu yaomam�z�n sebebi ayn� e posta adresine sahip 2 hesab�n a��lmam ihtimalini korumak 
*/
CREATE TRIGGER KullaniciAyniMailEngeli
ON Kullanicilar
AFTER INSERT, UPDATE
AS
BEGIN
DECLARE @GelenMail NVARCHAR(50);
    DECLARE @KendiID INT;





    SELECT TOP 1 @GelenMail = Eposta, @KendiID = Kullanici_id FROM inserted;


    IF EXISTS (SELECT * FROM Kullanicilar WHERE Eposta = @GelenMail AND Kullanici_id <> @KendiID)
    BEGIN
        -- Hata mesaj�m�z
        RAISERROR ('Hata: Bu e-posta adresi zaten kullan�mda! L�tfen ba�ka bir adres deneyin.', 16, 1);
        
        -- ��lemi iptal et
        ROLLBACK TRANSACTION;
    END
END;
GO

















