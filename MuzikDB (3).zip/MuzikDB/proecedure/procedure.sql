CREATE PROCEDURE sp_AlbumSarkilariniListele
    @AlbumId INT
AS
/*
Bir fonksiyon olu�turuyor 
*/
BEGIN
    SELECT 
        S.Sarki_id,
        S.Ad AS Sarki_Adi,
        S.Yayin_tarihi,
        T.Tur_adi
    FROM Sarkilar S
    INNER JOIN Turler T ON S.Tur_id = T.Tur_id
    WHERE S.Album_id = @AlbumId;
END;