USE MuzikDB;
GO
/*e�er kullan�c� hep bo� �alma listeleri olu�turursa bu bizim zarar�m�za �unk� 
biz o kadar veritaban�nda o veriye kar��l�k yer tutucaz
ve bu bizim i�in bir mali kay�p olmu� olucak 
*/
CREATE TRIGGER BosalanListeyiSil
ON CalmaListesiSarkilari
AFTER DELETE
AS
BEGIN
DECLARE @IslemYapilanListeID INT;
    DECLARE @KalanSayisi INT;

    SELECT TOP 1 @IslemYapilanListeID = Calmalistesi_id FROM deleted;

    SELECT @KalanSayisi = COUNT(*) 
    FROM CalmaListesiSarkilari 
    WHERE Calmalistesi_id = @IslemYapilanListeID;
   
   
   IF (@KalanSayisi = 0)
    BEGIN
        -- Ana tablodan (CalmaListeleri) o listeyi siliyoruz
        DELETE FROM CalmaListeleri WHERE Calmalistesi_id = @IslemYapilanListeID;

   PRINT '�alma listesindeki son �ark�da silindi�inden �alma listeside silindi';
    END
END;
GO