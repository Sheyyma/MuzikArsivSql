CREATE TRIGGER Sarki_ZorunluAlanVeReferansKontrolu
ON Sarkilar
AFTER INSERT, UPDATE
AS
BEGIN
    
    -- (Tablo yap�n�zda NOT NULL olsa bile trigger mant��� gere�i bu kontrol� buraya ekliyoruz)
    IF EXISTS (SELECT * FROM inserted WHERE Album_id IS NULL OR Tur_id IS NULL)
    BEGIN
        RAISERROR ('HATA: Bir �ark� mutlaka bir Alb�me ve bir M�zik T�r�ne ait olmal�d�r! (Alanlar bo� b�rak�lamaz)', 16, 1);
        ROLLBACK TRANSACTION; -- ��lemi iptal et
        RETURN;
    END

   
    IF EXISTS (
        SELECT i.Sarki_id 
        FROM inserted i
        LEFT JOIN Albumler a ON i.Album_id = a.Album_id
        WHERE a.Album_id IS NULL -- E�le�en bir alb�m bulunamad�ysa
    )
    BEGIN
        RAISERROR ('HATA: Girilen Alb�m ID sistemde kay�tl� de�il. Ge�erli bir alb�m se�melisiniz.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END

    IF EXISTS (
        SELECT i.Sarki_id 
        FROM inserted i
        LEFT JOIN Turler t ON i.Tur_id = t.Tur_id
        WHERE t.Tur_id IS NULL -- E�le�en bir t�r bulunamad�ysa
    )
    BEGIN
        RAISERROR ('HATA: Girilen T�r ID sistemde kay�tl� de�il. Ge�erli bir m�zik t�r� se�melisiniz.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
END;
GO