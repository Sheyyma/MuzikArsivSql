

/* hi�bir saant��n�n silinemeyeci�ini yapmam�z laz�m ��nk� m�zik
                      asla yok olamaz
                      her zaman ihtiya� vard�r*/



USE MuzikDB;
GO

CREATE TRIGGER trg_SanatciSilmeEngeli
ON Sanatcilar
AFTER DELETE
AS
BEGIN
    /* Burada silme i�lemi tetiklendi�inde araya giriyoruz.
       Veritaban� bozulmas�n diye sanat�� silmeyi engelliyoruz.
    */
    RAISERROR ('Hata:Hi�bir Sanat��y� silinemez! .', 16, 1);
    ROLLBACK TRANSACTION;
END;
GO