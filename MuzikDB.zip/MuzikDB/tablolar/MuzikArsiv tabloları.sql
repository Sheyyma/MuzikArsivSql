CREATE DATABASE MuzikDB;
GO
USE MuzikDB;
GO
CREATE TABLE Kullanicilar (
    Kullanici_id INT IDENTITY(1,1) PRIMARY KEY,
    Kullanici_adi NVARCHAR(50) NOT NULL,
    Eposta NVARCHAR(100) NOT NULL UNIQUE,
    Parola NVARCHAR(255) NOT NULL,
    Kayit_tarihi DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE Sanatcilar (
    Sanatci_id INT IDENTITY(1,1) PRIMARY KEY,
    Kullanici_adi NVARCHAR(50) NOT NULL,
    Ad NVARCHAR(50) NOT NULL,
    Soyad NVARCHAR(50) NULL,
    Eposta NVARCHAR(100) NOT NULL UNIQUE,
    Cikis_yili SMALLINT NULL,
    CONSTRAINT CK_Sanatcilar_CikisYili CHECK (Cikis_yili IS NULL OR (Cikis_yili BETWEEN 1900 AND 2100))
);
GO
CREATE TABLE Turler (
    Tur_id INT IDENTITY(1,1) PRIMARY KEY,
    Tur_adi NVARCHAR(50) NOT NULL UNIQUE
);
GO
CREATE TABLE Albumler (
    Album_id INT IDENTITY(1,1) PRIMARY KEY,
    Sanatci_id INT NOT NULL,
    Ad NVARCHAR(100) NOT NULL,
    Yayin_yili SMALLINT NULL,
    CONSTRAINT CK_Albumler_YayinYili CHECK (Yayin_yili IS NULL OR (Yayin_yili BETWEEN 1900 AND 2100)),
    CONSTRAINT FK_Albumler_Sanatcilar
        FOREIGN KEY (Sanatci_id) REFERENCES Sanatcilar(Sanatci_id)
);
GO
CREATE TABLE Sarkilar (
    Sarki_id INT IDENTITY(1,1) PRIMARY KEY,
    Album_id INT NOT NULL,
    Tur_id INT NOT NULL,
    Ad NVARCHAR(150) NOT NULL,
    Sure_saniye INT NOT NULL,
    Yayin_tarihi DATE NULL,

    CONSTRAINT CK_Sarkilar_Sure CHECK (Sure_saniye > 0 AND Sure_saniye <= 60*60*2),

    CONSTRAINT FK_Sarkilar_Albumler
        FOREIGN KEY (Album_id) REFERENCES Albumler(Album_id),

    CONSTRAINT FK_Sarkilar_Turler
        FOREIGN KEY (Tur_id) REFERENCES Turler(Tur_id)
);
GO
CREATE TABLE CalmaListeleri (
    Calmalistesi_id INT IDENTITY(1,1) PRIMARY KEY,
    Kullanici_id INT NOT NULL,
    Liste_adi NVARCHAR(100) NOT NULL,
    Olusturulma_tarihi DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT FK_CalmaListeleri_Kullanicilar
        FOREIGN KEY (Kullanici_id) REFERENCES Kullanicilar(Kullanici_id)
);
GO
CREATE TABLE CalmaListesiSarkilari (
    Calmalistesi_id INT NOT NULL,
    Sarki_id INT NOT NULL,
    Eklenme_tarihi DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    Sira INT NULL,

    CONSTRAINT PK_CalmaListesiSarkilari PRIMARY KEY (Calmalistesi_id, Sarki_id),

    CONSTRAINT FK_CLS_CalmaListeleri
        FOREIGN KEY (Calmalistesi_id) REFERENCES CalmaListeleri(Calmalistesi_id)
        ON DELETE CASCADE,

    CONSTRAINT FK_CLS_Sarkilar
        FOREIGN KEY (Sarki_id) REFERENCES Sarkilar(Sarki_id)
);
GO