BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO CalmaListeleri (Kullanici_id, Liste_adi)
    VALUES (1, 'Favorilerim');

   
    DECLARE @CalmaListesiID INT;
    SET @CalmaListesiID = SCOPE_IDENTITY();

    
    INSERT INTO CalmaListesiSarkilari (Calmalistesi_id, Sarki_id, Sira)
    VALUES (@CalmaListesiID, 1, 1);

    
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH

    ROLLBACK TRANSACTION;

    
    PRINT '��lem s�ras�nda hata olu�tu.';
END CATCH;

USE MuzikDB;
GO

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO CalmaListeleri (Kullanici_id, Liste_adi)
    VALUES (1, 'Hatal� Liste');

    DECLARE @CalmaListesiID INT;
    SET @CalmaListesiID = SCOPE_IDENTITY();

    
    INSERT INTO CalmaListesiSarkilari (Calmalistesi_id, Sarki_id, Sira)
    VALUES (@CalmaListesiID, 9999, 1);

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'HATA OLU�TU ? TRANSACTION GER� ALINDI';
END CATCH;