USE MuzikDB;
GO

CREATE TRIGGER KullaniciAdiTekrarEngeli
ON Kullanicilar
AFTER INSERT, UPDATE
AS
BEGIN

DECLARE @GelenNick NVARCHAR(100);
    DECLARE @KendiID INT;




    SELECT TOP 1 @GelenNick = Kullanici_adi, @KendiID = Kullanici_id FROM inserted;


    IF EXISTS (SELECT * FROM Kullanicilar WHERE Kullanici_adi = @GelenNick AND Kullanici_id <> @KendiID)
    BEGIN
        -- Hata mesaj� (Kullan�c�ya nazik�e uyaral�m)
        RAISERROR (' Bu Kullan�c� Ad� maalesef al�nm��! L�tfen farkl� isim bulun.', 16, 1);
        
        -- ��lemi geri sar, kaydetme
        ROLLBACK TRANSACTION;
    END
END;
GO








