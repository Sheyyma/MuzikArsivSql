EXEC sp_AlbumSarkilariniListele @AlbumId = 1;
