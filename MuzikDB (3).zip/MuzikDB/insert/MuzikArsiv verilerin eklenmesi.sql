USE MuzikDB;
GO


INSERT INTO Turler (Tur_adi) 
VALUES 
--ilk �nce 8 tane t�r ekledik  ve bunlar�n idleri akl�m�zda kals�n diye yanda yaz�k 

('Pop'),            -- ID:1
('Rock'),           -- ID: 2
('Rap'),    -- ID: 3
('Metal'),          -- ID:4
('R&B'),            -- ID: 5
('Arabesk'),        -- ID 6
('Alternatif'),     -- ID: 7
('Indie');          -- ID 8



INSERT INTO Kullanicilar (Kullanici_adi, Eposta, Parola)
VALUES
--Burda s�ras�yla kullan�c� adlar�n� epostalar� ve parolar�n� ald�k ve bunlar�n ger�ek�i olmas�n� istedik 

('ahmet8', 'ahmet@gmail.com', '1234') ,
('zeynep7', 'zeynep@gmail.com', '1234') ,
('kaz�m6', 'kaz�m@gmail.com', '1234') ,
('dila5', 'dila@gmail.com', '1234') ,
('burakemre4', 'burak@gmail.com', '1234')  ,
('dilara3', 'dilara@gmail.com', '1234') ,
('furkan2', 'furkan@gmail.com', '1234') ,
('aysegul1', 'aysegul@gmail.com', '1234' ),
('ziya123', 'ziya@gmail.com', '1234'  )  ,
('sheyma', 'sheyma@gmail.com', '1234')
;



INSERT INTO Sanatcilar (Kullanici_adi, Ad, Soyad, Eposta, Cikis_yili)
VALUES
--sanat��lar�n ger�ek sanat��lardan bilgilerini ald�k ama epostalar�n� kendimiz atad�k ve  ��k�� tarhlerinide girdik

('sezen_Aksu', 'Sezen', 'Aksu', 'sezen@aksu.com', 1975 ),           
('muslum_baba', 'M�sl�m', 'G�rses', 'baba@muslum.com',  1978),       
('tarkan', 'Tarkan', 'Teveto�lu', 'tarkan@megastar.com', 1992 ),     
('duman', 'Duman', NULL, 'info@duman.com', 1999),                   
('ceza', 'Bilgin', '�z�alkan', 'ceza@rap.com', 2002)   ,               
('manga', 'maNga', NULL, 'iletisim@manga.com', 2001)   ,               
('sebnem_ferah', '�ebnem', 'Ferah', 'sebo@rock.com',  1996),             
('eminem', 'Marshall', 'Mathers', 'eminem@shady.com',  1996) ,        
('rihanna', 'Rihanna', 'Fenty', 'riri@fenty.com',  2005),            
('metallica', 'Metallica', NULL, 'band@metallica.com',  1981),       
('queen', 'Queen', NULL, 'freddie@queen.com', 1970) ,                
('adele', 'Adele', 'Adkins', 'adele@uk.com', 2008),                 
('weeknd', 'Abel', 'Tesfaye', 'weeknd@xo.com', 2010),              
('lp_band', 'Linkin Park', NULL, 'lp@nu.com', 2000),               
('bruno_mars', 'Bruno', 'Mars', 'bruno@mars.com', 2010);              



INSERT INTO Albumler (Sanatci_id, Ad, Yayin_yili)
VALUES
--burda s�ras�yla sant��lardan ald���m�z baz� albimleri girdik 
(1, 'G�l�mse', 1991),               
(1, 'Biraz Pop Biraz Sezen', 2017),
(2, 'Sand�k', 2009),               
(2, 'A�k Tesad�fleri Sever', 2006), 
(3, 'Karma', 2001),   
(3, '10', 2017),
(4, 'Belki Al��man Laz�m', 2002),   
(4, 'Seni Kendime Saklad�m', 2005),
(5, 'Rapstar', 2004),              
(5, 'Yerli Plaka', 2006),
(6, '�ehr-i H�z�n', 2009),         
(6, 'maNga', 2004),
(7, 'Kad�n', 1996),                
(7, 'Od', 2013),                   
(8, 'The Eminem Show', 2002), 
(8, 'Recovery', 2010),             
(9, 'Good Girl Gone Bad', 2007),   
(9, 'Anti', 2016),                 
(10, 'Black Album', 1991),         
(10, 'Master of Puppets', 1986),
(11, 'A Night at the Opera', 1975),
(12, '21', 2011),       
(13, 'Starboy', 2016),      
(13, 'After Hours', 2020),   
(14, 'Hybrid Theory', 2000),        
(14, 'Meteora', 2003),    
(15, 'Doo-Wops & Hooligans', 2010),
(15, '24K Magic', 2016);           




INSERT INTO Sarkilar (Album_id, Tur_id, Ad, Sure_saniye, Yayin_tarihi) VALUES

-- burda albumleri girdik ve �ark�lar� girdik ve s�relerini ve ��k�� tarihlerini girdik
--ama ilk ba�ta ark�lar�n bulunduklar� alb�mleri ve daha sonras�nda t�rlerini daha sonrasinde geri kalan verileri girdik


(1, 1, 'G�l�mse', 285, '1991-01-01'),
(1, 1, 'Vazge�tim', 309, '1991-01-01'),
(1, 1, 'Hadi Bakal�m', 296, '1991-01-01'),
(2, 1, '�hanetten Geri Kalan', 250, '2017-05-15'),
(3, 6, '�tiraz�m Var', 245, '2009-02-01'),
(3, 6, 'Tutam�yorum Zaman�', 230, '2009-02-01'),
(4, 7, 'Nil�fer', 260, '2006-04-18'),
(4, 7, 'Affet', 285, '2006-04-18'),
(5, 1, 'Kuzu Kuzu', 232, '2001-07-15'),
(5, 1, 'H�p', 218, '2001-07-15'),
(5, 1, 'Verme', 290, '2001-07-15'),
(6, 1, 'Yolla', 226, '2017-06-15'),
(7, 2, 'Bu Ak�am', 205, '2002-04-04'),
(7, 2, 'Her �eyi Yak', 256, '2002-04-04'),
(8, 2, 'Seni Kendime Saklad�m', 242, '2005-06-07'),
(8, 2, 'Aman Aman', 235, '2005-06-07'),
(9, 3, 'Holocaust', 208, '2004-01-01'),
(9, 3, 'Neyim Var Ki', 245, '2004-01-01'),
(10, 3, 'Yerli Plaka', 230, '2006-09-01'),
(10, 3, 'Fark Var', 215, '2006-09-01'),
(11, 7, 'Cevaps�z Sorular', 275, '2009-04-15'),
(11, 7, 'D�nyan�n Sonuna Do�mu�um', 260, '2009-04-15'),
(12, 7, 'Bir Kad�n �izeceksin', 238, '2004-12-14'),
(13, 2, 'Vazge�tim D�nyadan', 285, '1996-11-15'),
(13, 2, 'Ya�murlar', 295, '1996-11-15'),
(15, 3, 'Without Me', 290, '2002-05-26'),
(15, 3, 'Sing for the Moment', 339, '2002-05-26'),
(15, 3, 'Cleanin Out My Closet', 297, '2002-05-26'),
(16, 3, 'Not Afraid', 248, '2010-04-29'),
(16, 3, 'Love The Way You Lie', 263, '2010-04-29'),
(17, 5, 'Umbrella', 275, '2007-03-29'),
(17, 5, 'Shut Up and Drive', 213, '2007-03-29'),
(18, 5, 'Work', 219, '2016-01-27'),
(19, 4, 'Enter Sandman', 331, '1991-08-12'),
(19, 4, 'The Unforgiven', 387, '1991-08-12'),
(19, 4, 'Nothing Else Matters', 388, '1991-08-12'),
(20, 4, 'Master of Puppets', 515, '1986-03-03'),
(21, 2, 'Bohemian Rhapsody', 354, '1975-10-31'),
(21, 2, 'Love of My Life', 217, '1975-10-31'),
(22, 1, 'Rolling in the Deep', 228, '2011-01-24'),
(22, 1, 'Someone Like You', 285, '2011-01-24'),
(22, 1, 'Set Fire to the Rain', 242, '2011-01-24'),
(23, 5, 'Starboy', 230, '2016-09-21'),
(24, 5, 'Blinding Lights', 200, '2019-11-29'),
(24, 5, 'Save Your Tears', 215, '2020-03-20'),
(25, 2, 'In the End', 216, '2000-10-24'),
(25, 2, 'Crawling', 209, '2000-10-24'),
(26, 2, 'Numb', 187, '2003-03-25'),
(27, 1, 'Grenade', 222, '2010-09-28'),
(27, 1, 'Just the Way You Are', 220, '2010-09-28'),
(28, 1, '24K Magic', 226, '2016-10-07');


INSERT INTO CalmaListeleri (Kullanici_id, Liste_adi)

VALUES
--burda her kullan�c�n�n kendine �zg� olan �alma listelerini girdik bu �alma listeleri n-n �eklide yapt�k �uku her kullan�c� birden fazla �alma listeleri olabilir birde 
--herkese a��k �alma listeleri olaiblir
(1, 'Ahmet Favori'),
(1, 'piyasa �ark�lar�'),
(3, 'Sadece Rock'),
(3, 'a��r metal'),
(2, 'T�rk�e'),
(7, 'Efkarl�yken'),
(10, 'Ders �al���rken');

INSERT INTO CalmaListesiSarkilari (Calmalistesi_id, Sarki_id, Sira)
VALUES
--burda �almalistelerine baz� �ark�lar� ekledik ve bu eklemeleri �ark�lar�n idlerine g�re yapt�k ve s�ralar�n� koduk

(1, 15, 1), (1, 19, 2),(1, 35, 3),

(2, 5, 1), (2, 25, 3), (2, 1, 2),  

(3, 9, 1),(3, 10, 2),(3, 39, 3),(3, 41, 4),

(4, 19, 1),(4, 20, 2),(4, 22, 3), 

(5, 30, 1),(5, 45, 2), (5, 7, 3), 

(6, 5, 1),(6, 6, 2),(6, 2, 3);



GO