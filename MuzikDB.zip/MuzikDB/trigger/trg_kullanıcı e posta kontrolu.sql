USE MuzikDB;
GO

CREATE TRIGGER KullaniciEpostaKontrol
ON Kullanicilar
AFTER INSERT, UPDATE
AS
BEGIN

IF EXISTS (SELECT * FROM inserted WHERE Eposta NOT LIKE '%@%' OR Eposta NOT LIKE '%.%')
    BEGIN
        -- Hata mesaj�n� verelim
        RAISERROR ('Hata: Girdi�iniz e-posta adresi ge�ersiz! (L�tfen @ ve . i�aretlerini kontrol edin)', 16, 1);
        
        -- ��lemi iptal et
        ROLLBACK TRANSACTION;
    END
END;
GO







